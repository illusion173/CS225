/* 
*	LabOne.java 
*	Written By: Troy Neubauer
*	CS 225 Spring 2021
*/

public class LabOne {

	public static int year;

	public static void main(String[] args) {
		String firstName = "Troy";
		String lastName = "Neubauer";
		year = 2021;
		System.out.println("Hello My Name is: ");
		System.out.println(firstName + " " + lastName);
		System.out.println("This is my first program of Spring " + year);

	}

}
